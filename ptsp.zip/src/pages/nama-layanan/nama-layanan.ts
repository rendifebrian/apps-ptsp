import { Component } from '@angular/core';
import { IonicPage, NavController, NavParams, ModalController } from 'ionic-angular';
import { ListLayananPage } from './list_layanan';

/**
 * Generated class for the NamaLayananPage page.
 *
 * See https://ionicframework.com/docs/components/#navigation for more info on
 * Ionic pages and navigation.
 */

@IonicPage()
@Component({
  selector: 'page-nama-layanan',
  templateUrl: 'nama-layanan.html',
})
export class NamaLayananPage {

  constructor(public navCtrl: NavController, public navParams: NavParams, public modalCtrl: ModalController) {
  }

  ionViewDidLoad() {
    console.log('ionViewDidLoad NamaLayananPage');
  }

  list_detail()
  {
    this.modalCtrl.create(ListLayananPage).present();
  }

}
