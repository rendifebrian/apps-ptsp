import { Component } from '@angular/core';
import { IonicPage, NavController, NavParams, ModalController, ViewController } from 'ionic-angular';
import { Select2Option } from '../extra/select2_options';
import { GlobalProvider } from '../../providers/global';

/**
 * Generated class for the InputPenyelesaianLayananPage page.
 *
 * See https://ionicframework.com/docs/components/#navigation for more info on
 * Ionic pages and navigation.
 */

@IonicPage()
@Component({
  selector: 'page-input-penyelesaian-layanan',
  templateUrl: 'input-penyelesaian-layanan.html',
})
export class InputPenyelesaianLayananPage {

  criteria = {
    no_registrasi : '',
  }

  constructor(
    public navCtrl: NavController, 
    public navParams: NavParams, 
    public modalCtrl : ModalController, 
    public globalProvider : GlobalProvider,
    public viewCtrl : ViewController,
  ) {
  }

  ionViewDidLoad() {
    console.log('ionViewDidLoad InputPenyelesaianLayananPage');
  }

  daftar_data_layanan()
  {
    let modal = this.modalCtrl.create(Select2Option, {from_module:'penyelesaian_layanan'})
    modal.onDidDismiss(data => {
      this.criteria.no_registrasi = data;
    })
    modal.present();
  }

  storeData(form:any)
  {
		this.globalProvider.toastDefault("Data Berhasil Disimpan.");
		this.viewCtrl.dismiss();
  }

}
