import { Component } from '@angular/core';
import { IonicPage, NavController, NavParams, ModalController } from 'ionic-angular';
import { FormDataLayanan } from './form_data_layanan';

/**
 * Generated class for the InputDataLayananPage page.
 *
 * See https://ionicframework.com/docs/components/#navigation for more info on
 * Ionic pages and navigation.
 */

@IonicPage()
@Component({
  selector: 'page-input-data-layanan',
  templateUrl: 'input-data-layanan.html',
})
export class InputDataLayananPage {

  constructor(public navCtrl: NavController, public navParams: NavParams, public modalCtrl : ModalController) {
  }

  ionViewDidLoad() {
    console.log('ionViewDidLoad InputDataLayananPage');
  }

  input_data()
  {
    this.modalCtrl.create(FormDataLayanan).present();
  }

}
