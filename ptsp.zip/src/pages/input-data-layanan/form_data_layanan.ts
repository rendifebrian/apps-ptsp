import { Component } from '@angular/core';
import { IonicPage, NavController, NavParams, ModalController, ViewController } from 'ionic-angular';
import { GlobalProvider } from '../../providers/global';

/**
 * Generated class for the InputDataLayananPage page.
 *
 * See https://ionicframework.com/docs/components/#navigation for more info on
 * Ionic pages and navigation.
 */

@IonicPage()
@Component({
  selector: 'page-input-data-layanan',
  templateUrl: 'form_data_layanan.html',
})
export class FormDataLayanan {

  constructor(
     public navCtrl: NavController, 
     public navParams: NavParams, 
     public modalCtrl : ModalController, 
		 public viewCtrl : ViewController,
		 public globalProvider : GlobalProvider,
  ) {

  }

  ionViewDidLoad() {
    console.log('ionViewDidLoad InputDataLayananPage');
  }

  storeData(form:any)
  {
		this.globalProvider.toastDefault("Data Berhasil Disimpan.");
		this.viewCtrl.dismiss();
  }


}
